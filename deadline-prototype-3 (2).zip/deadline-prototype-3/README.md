# DEADLINE — Murder at City Engineering College (Prototype 3)

A standalone, offline-friendly, mobile-first fictional mystery prototype. It keeps the original THE LAST MESSAGE interaction pattern: phone lock screen → WhatsApp-style conversation with Shubendhu → case-file attachment → investigation app.

## Run

1. Download and extract `deadline-prototype-3.zip`.
2. Open `index.html` in a recent desktop or mobile browser.
3. Tap the notification to open Shubendhu's chat; choose a reply and then open the attachment to begin the case.

No installation, account, server, external fonts, or network connection is required. Browser audio should start after the first tap due to mobile autoplay rules.

## Core gameplay

- Six campus locations reveal evidence and five ARYA memory shards.
- Eight suspects have illustrated, animated portraits and interactive interviews.
- The timeline is rebuilt by tapping events in chronological order.
- Restore ARYA, compare three sound samples, and identify the repeated chime.
- Final accusation requires WHO + HOW + WHY and exactly three evidence items.
- A 60-second in-game help prompt can be answered or skipped.
- Sound, ambience, volume, and motion controls are available from the settings button.
- Progress is saved locally in this browser. Use Reset case to start over.

## Continuity with the earlier interface

The initial interaction remains a lock-screen WhatsApp notification from Shubendhu saying “Hi.” Every intro chat turn has two reply choices that converge on the same attachment. The crime details appear only after the attachment is opened. The investigation keeps a phone-first dark/cyan interface and adds red/cyan suspense accents, character portraits, messages, map, suspects, evidence notebook, timeline, ARYA, and final accusation tabs.

All characters, events, college systems, and records are fictional.
